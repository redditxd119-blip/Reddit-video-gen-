import { useState, useEffect } from 'react'
import axios from 'axios'
import './App.css'
import Dashboard from './pages/Dashboard'
import Stories from './pages/Stories'
import Videos from './pages/Videos'
import Settings from './pages/Settings'

function App() {
  const [currentPage, setCurrentPage] = useState('dashboard')
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchStats()
  }, [])

  const fetchStats = async () => {
    try {
      const response = await axios.get('/api/stats')
      setStats(response.data.data)
    } catch (error) {
      console.error('خطأ في جلب الإحصائيات:', error)
    } finally {
      setLoading(false)
    }
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard stats={stats} onRefresh={fetchStats} />
      case 'stories':
        return <Stories />
      case 'videos':
        return <Videos />
      case 'settings':
        return <Settings />
      default:
        return <Dashboard stats={stats} onRefresh={fetchStats} />
    }
  }

  return (
    <div className="app">
      <nav className="navbar">
        <div className="navbar-brand">
          <h1>🎬 Reddit Video Generator</h1>
        </div>
        <div className="navbar-menu">
          <button 
            className={`nav-button ${currentPage === 'dashboard' ? 'active' : ''}`}
            onClick={() => setCurrentPage('dashboard')}
          >
            📊 لوحة التحكم
          </button>
          <button 
            className={`nav-button ${currentPage === 'stories' ? 'active' : ''}`}
            onClick={() => setCurrentPage('stories')}
          >
            📖 القصص
          </button>
          <button 
            className={`nav-button ${currentPage === 'videos' ? 'active' : ''}`}
            onClick={() => setCurrentPage('videos')}
          >
            🎥 الفيديوهات
          </button>
          <button 
            className={`nav-button ${currentPage === 'settings' ? 'active' : ''}`}
            onClick={() => setCurrentPage('settings')}
          >
            ⚙️ الإعدادات
          </button>
        </div>
      </nav>

      <main className="main-content">
        {loading ? (
          <div className="loading">جاري التحميل...</div>
        ) : (
          renderPage()
        )}
      </main>
    </div>
  )
}

export default App
