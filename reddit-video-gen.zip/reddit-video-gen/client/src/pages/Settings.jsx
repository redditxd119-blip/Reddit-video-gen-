import { useState, useEffect } from 'react'
import axios from 'axios'
import '../styles/Settings.css'

export default function Settings() {
  const [subreddits, setSubreddits] = useState([])
  const [newSubreddit, setNewSubreddit] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchSubreddits()
  }, [])

  const fetchSubreddits = async () => {
    try {
      const response = await axios.get('/api/subreddits')
      setSubreddits(response.data.data || [])
    } catch (error) {
      console.error('خطأ في جلب الـ subreddits:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddSubreddit = async (e) => {
    e.preventDefault()
    if (!newSubreddit.trim()) {
      alert('⚠️ أدخل اسم subreddit')
      return
    }

    try {
      await axios.post('/api/subreddits', { name: newSubreddit })
      alert('✅ تم إضافة الـ subreddit بنجاح')
      setNewSubreddit('')
      fetchSubreddits()
    } catch (error) {
      alert('❌ خطأ في إضافة الـ subreddit: ' + error.message)
    }
  }

  return (
    <div className="settings-page">
      <h2>⚙️ الإعدادات</h2>
      
      <div className="settings-section">
        <h3>📚 إدارة Subreddits</h3>
        
        <form onSubmit={handleAddSubreddit} className="add-subreddit-form">
          <input
            type="text"
            placeholder="أدخل اسم subreddit (مثال: nosleep)"
            value={newSubreddit}
            onChange={(e) => setNewSubreddit(e.target.value)}
            className="input-field"
          />
          <button type="submit" className="btn-primary">
            ➕ إضافة
          </button>
        </form>

        {loading ? (
          <div className="loading">جاري التحميل...</div>
        ) : subreddits.length === 0 ? (
          <div className="empty-state">
            <p>📭 لا توجد subreddits مضافة</p>
          </div>
        ) : (
          <div className="subreddit-list">
            {subreddits.map((sub) => (
              <div key={sub.id} className="subreddit-item">
                <div className="subreddit-info">
                  <h4>r/{sub.name}</h4>
                  <p>
                    {sub.enabled ? '✅ مفعل' : '❌ معطل'}
                  </p>
                </div>
                <div className="subreddit-actions">
                  <button className="btn-secondary">✏️ تعديل</button>
                  <button className="btn-danger">🗑️ حذف</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="settings-section">
        <h3>🎬 إعدادات الفيديو</h3>
        <div className="settings-group">
          <label>
            <span>صيغة الفيديو:</span>
            <select className="input-field">
              <option>عمودي (9:16) - TikTok/Shorts</option>
              <option>أفقي (16:9) - YouTube</option>
              <option>كلاهما</option>
            </select>
          </label>

          <label>
            <span>جودة الفيديو:</span>
            <select className="input-field">
              <option>عالية (1080p)</option>
              <option>متوسطة (720p)</option>
              <option>منخفضة (480p)</option>
            </select>
          </label>

          <label>
            <span>سرعة الفيديو:</span>
            <input type="range" min="0.5" max="2" step="0.1" defaultValue="1" className="input-field" />
          </label>
        </div>
      </div>

      <div className="settings-section">
        <h3>🔔 إعدادات الإشعارات</h3>
        <div className="settings-group">
          <label className="checkbox-label">
            <input type="checkbox" defaultChecked />
            <span>إشعارات عند اكتمال الفيديو</span>
          </label>
          <label className="checkbox-label">
            <input type="checkbox" defaultChecked />
            <span>إشعارات عند حدوث خطأ</span>
          </label>
          <label className="checkbox-label">
            <input type="checkbox" />
            <span>إشعارات البريد الإلكتروني</span>
          </label>
        </div>
      </div>

      <div className="settings-actions">
        <button className="btn-primary">💾 حفظ الإعدادات</button>
        <button className="btn-secondary">🔄 إعادة تعيين</button>
      </div>
    </div>
  )
}
