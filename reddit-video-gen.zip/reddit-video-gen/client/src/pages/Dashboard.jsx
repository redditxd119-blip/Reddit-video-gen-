import { useState } from 'react'
import axios from 'axios'
import '../styles/Dashboard.css'

export default function Dashboard({ stats, onRefresh }) {
  const [loading, setLoading] = useState(false)

  const handleFetchStories = async () => {
    setLoading(true)
    try {
      const response = await axios.post('/api/fetch-stories')
      alert(`✅ ${response.data.message}`)
      onRefresh()
    } catch (error) {
      alert('❌ خطأ في جلب القصص: ' + error.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="dashboard">
      <h2>📊 لوحة التحكم</h2>
      
      <div className="stats-grid">
        <div className="stat-card">
          <h3>📖 إجمالي القصص</h3>
          <p className="stat-value">{stats?.totalStories || 0}</p>
        </div>
        
        <div className="stat-card">
          <h3>🎥 إجمالي الفيديوهات</h3>
          <p className="stat-value">{stats?.totalVideos || 0}</p>
        </div>
        
        <div className="stat-card">
          <h3>✅ الفيديوهات المكتملة</h3>
          <p className="stat-value" style={{ color: '#00d966' }}>
            {stats?.completedVideos || 0}
          </p>
        </div>
        
        <div className="stat-card">
          <h3>⏳ الفيديوهات قيد المعالجة</h3>
          <p className="stat-value" style={{ color: '#ffb800' }}>
            {stats?.processingVideos || 0}
          </p>
        </div>
      </div>

      <div className="action-section">
        <h3>🔄 الإجراءات السريعة</h3>
        <button 
          className="action-button"
          onClick={handleFetchStories}
          disabled={loading}
        >
          {loading ? 'جاري الجلب...' : '🔄 جلب القصص الآن'}
        </button>
      </div>

      <div className="info-section">
        <h3>ℹ️ معلومات النظام</h3>
        <div className="info-content">
          <p>✅ النظام يعمل بشكل طبيعي</p>
          <p>🔄 الجدولة التلقائية: مفعلة (كل 24 ساعة)</p>
          <p>📡 الاتصال بـ Reddit API: متصل</p>
          <p>💾 قاعدة البيانات: سليمة</p>
        </div>
      </div>
    </div>
  )
}
