import { useState, useEffect } from 'react'
import axios from 'axios'
import '../styles/Stories.css'

export default function Stories() {
  const [stories, setStories] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')

  useEffect(() => {
    fetchStories()
  }, [])

  const fetchStories = async () => {
    try {
      const response = await axios.get('/api/stories')
      setStories(response.data.data || [])
    } catch (error) {
      console.error('خطأ في جلب القصص:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'completed':
        return <span className="badge badge-success">✅ مكتملة</span>
      case 'processing':
        return <span className="badge badge-warning">⏳ قيد المعالجة</span>
      case 'pending':
        return <span className="badge badge-info">📋 معلقة</span>
      default:
        return <span className="badge badge-secondary">❓ غير معروف</span>
    }
  }

  return (
    <div className="stories-page">
      <h2>📖 القصص</h2>
      
      <div className="filter-section">
        <button 
          className={`filter-button ${filter === 'all' ? 'active' : ''}`}
          onClick={() => setFilter('all')}
        >
          الكل
        </button>
        <button 
          className={`filter-button ${filter === 'completed' ? 'active' : ''}`}
          onClick={() => setFilter('completed')}
        >
          مكتملة
        </button>
        <button 
          className={`filter-button ${filter === 'processing' ? 'active' : ''}`}
          onClick={() => setFilter('processing')}
        >
          قيد المعالجة
        </button>
      </div>

      {loading ? (
        <div className="loading">جاري التحميل...</div>
      ) : stories.length === 0 ? (
        <div className="empty-state">
          <p>📭 لا توجد قصص حالياً</p>
          <p>اضغط على "جلب القصص" في لوحة التحكم</p>
        </div>
      ) : (
        <div className="stories-grid">
          {stories.map((story) => (
            <div key={story.id} className="story-card">
              <div className="story-header">
                <h3>{story.title}</h3>
                {getStatusBadge(story.status)}
              </div>
              
              <div className="story-meta">
                <span>👤 {story.author}</span>
                <span>🔗 r/{story.subreddit}</span>
              </div>
              
              <p className="story-content">{story.content.substring(0, 200)}...</p>
              
              <div className="story-stats">
                <span>👍 {story.upvotes}</span>
                <span>💬 {story.comments}</span>
              </div>
              
              <div className="story-actions">
                <button className="btn-primary">📺 إنشاء فيديو</button>
                <button className="btn-secondary">👁️ عرض</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
