import { useState, useEffect } from 'react'
import axios from 'axios'
import '../styles/Videos.css'

export default function Videos() {
  const [videos, setVideos] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchVideos()
  }, [])

  const fetchVideos = async () => {
    try {
      const response = await axios.get('/api/videos')
      setVideos(response.data.data || [])
    } catch (error) {
      console.error('خطأ في جلب الفيديوهات:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return '#00d966'
      case 'processing':
        return '#ffb800'
      case 'failed':
        return '#ff4444'
      default:
        return '#2a3f5f'
    }
  }

  return (
    <div className="videos-page">
      <h2>🎥 الفيديوهات</h2>
      
      {loading ? (
        <div className="loading">جاري التحميل...</div>
      ) : videos.length === 0 ? (
        <div className="empty-state">
          <p>📭 لا توجد فيديوهات حالياً</p>
          <p>ابدأ بإنشاء فيديو من قصة موجودة</p>
        </div>
      ) : (
        <div className="videos-grid">
          {videos.map((video) => (
            <div key={video.id} className="video-card">
              <div className="video-thumbnail">
                <div className="thumbnail-placeholder">
                  🎬
                </div>
                <div className="status-badge" style={{ backgroundColor: getStatusColor(video.status) }}>
                  {video.status === 'completed' ? '✅' : video.status === 'processing' ? '⏳' : '❌'}
                </div>
              </div>
              
              <div className="video-info">
                <h3>{video.story_title || 'فيديو بدون عنوان'}</h3>
                
                <div className="video-meta">
                  <span>📝 الحالة: {video.status}</span>
                  <span>⏱️ المدة: {video.duration || 'N/A'} ثانية</span>
                </div>
                
                <div className="video-progress">
                  <div className="progress-bar">
                    <div 
                      className="progress-fill"
                      style={{ width: `${video.progress || 0}%` }}
                    ></div>
                  </div>
                  <span className="progress-text">{video.progress || 0}%</span>
                </div>
                
                <div className="video-actions">
                  {video.status === 'completed' && (
                    <>
                      <button className="btn-primary">📥 تحميل</button>
                      <button className="btn-secondary">📤 نشر</button>
                    </>
                  )}
                  {video.status === 'processing' && (
                    <button className="btn-secondary" disabled>⏳ جاري المعالجة...</button>
                  )}
                  {video.status === 'failed' && (
                    <button className="btn-danger">🔄 إعادة محاولة</button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
