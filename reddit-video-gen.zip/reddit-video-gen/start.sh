#!/bin/bash

echo "🚀 بدء تطبيق Reddit Video Generator..."

# تحقق من وجود node_modules
if [ ! -d "node_modules" ]; then
    echo "📦 تثبيت dependencies للـ server..."
    npm install
fi

if [ ! -d "client/node_modules" ]; then
    echo "📦 تثبيت dependencies للـ client..."
    cd client && npm install && cd ..
fi

# إنشاء مجلدات الإخراج
mkdir -p output/videos
mkdir -p output/audio
mkdir -p assets

echo "✅ التحضيرات اكتملت"
echo ""
echo "🔧 لتشغيل التطبيق:"
echo "  Terminal 1: npm start"
echo "  Terminal 2: cd client && npm run dev"
echo ""
echo "📍 الروابط:"
echo "  Server: http://localhost:3001"
echo "  Client: http://localhost:5173"
