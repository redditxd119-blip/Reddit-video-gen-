# 🚀 دليل النشر على Render

## الخطوة 1: إعداد GitHub

### 1.1 إنشاء مستودع GitHub
```bash
git init
git add .
git commit -m "Initial commit: Reddit Video Generator"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/reddit-video-gen.git
git push -u origin main
```

## الخطوة 2: إنشاء حساب على Render

1. اذهب إلى https://render.com
2. سجل بـ GitHub
3. وافق على الأذونات

## الخطوة 3: نشر التطبيق

### 3.1 نشر الـ Backend (API)
1. اذهب إلى https://dashboard.render.com
2. اضغط "New +" ثم "Web Service"
3. اختر مستودع GitHub الخاص بك
4. ملء البيانات:
   - **Name**: reddit-video-gen-api
   - **Environment**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Plan**: Free (أو مدفوع)

5. اضغط "Create Web Service"

### 3.2 نشر الـ Frontend (الواجهة)
1. اضغط "New +" ثم "Static Site"
2. اختر نفس المستودع
3. ملء البيانات:
   - **Name**: reddit-video-gen-client
   - **Build Command**: `cd client && npm install && npm run build`
   - **Publish Directory**: `client/dist`

4. اضغط "Create Static Site"

## الخطوة 4: إعدادات البيئة

### 4.1 إضافة متغيرات البيئة للـ Backend
في لوحة تحكم Render:
1. اذهب إلى Web Service الخاص بك
2. اضغط "Environment"
3. أضف المتغيرات:
   ```
   NODE_ENV=production
   PORT=3000
   DATABASE_PATH=/tmp/database.db
   ```

### 4.2 إضافة متغيرات البيئة للـ Frontend
في لوحة تحكم Render:
1. اذهب إلى Static Site الخاص بك
2. اضغط "Environment"
3. أضف المتغيرات إذا لزم الأمر

## الخطوة 5: التحقق من النشر

1. انتظر حتى ينتهي البناء (Build)
2. ستحصل على رابط مثل: `https://reddit-video-gen-api.onrender.com`
3. اختبر الـ API: `https://reddit-video-gen-api.onrender.com/api/stats`
4. الواجهة الأمامية ستكون على: `https://reddit-video-gen-client.onrender.com`

## الخطوة 6: الربط بين Frontend و Backend

في ملف `/client/src/App.jsx`، تأكد من تعديل رابط الـ API:

```javascript
const API_BASE_URL = process.env.NODE_ENV === 'production' 
  ? 'https://reddit-video-gen-api.onrender.com'
  : 'http://localhost:3001';
```

## 🔄 التحديثات التلقائية

عند كل push إلى GitHub:
1. Render سيكتشف التغييرات تلقائياً
2. سيقوم بـ rebuild التطبيق
3. سيتم نشر النسخة الجديدة تلقائياً

## 📊 مراقبة الأداء

في لوحة تحكم Render:
- اضغط على الخدمة
- اذهب إلى "Logs" لرؤية السجلات
- اذهب إلى "Metrics" لرؤية الأداء

## ⚠️ ملاحظات مهمة

1. **قاعدة البيانات**: 
   - حالياً تستخدم SQLite المحلية
   - للإنتاج، يفضل استخدام PostgreSQL

2. **الملفات المؤقتة**:
   - الفيديوهات والصوتيات تُحفظ في `/tmp`
   - قد تُحذف عند إعادة تشغيل الخادم

3. **الحد المجاني**:
   - الخادم قد ينام بعد 15 دقيقة من عدم النشاط
   - قد يستغرق الاستيقاظ بعض الوقت

## 🆘 استكشاف الأخطاء

### المشكلة: Build فشل
**الحل**: تحقق من السجلات (Logs) في Render

### المشكلة: Frontend لا يتصل بـ Backend
**الحل**: تأكد من تحديث رابط الـ API في App.jsx

### المشكلة: قاعدة البيانات لا تعمل
**الحل**: استخدم PostgreSQL بدلاً من SQLite

## 📞 الدعم

للمساعدة:
- اقرأ توثيق Render: https://render.com/docs
- تحقق من السجلات في لوحة التحكم
- افتح issue على GitHub

---

**تم إنشاء هذا الدليل لتسهيل النشر على Render** 🚀
