# 🎬 Reddit Video Generator

تطبيق متكامل لإنتاج فيديوهات Reddit تلقائياً بخلفية Minecraft Parkour مع ترجمة نصية وجدولة يومية.

## ✨ الميزات الرئيسية

- 📖 جلب قصص Reddit تلقائياً من عدة subreddits
- 🎬 تحويل النصوص إلى فيديوهات بخلفية Minecraft
- 📝 ترجمة نصية تلقائية (Subtitles)
- 🔄 جدولة يومية لتحديث القصص
- 📊 لوحة تحكم احترافية
- 📱 تصميم متجاوب (Responsive Design)
- 🔔 إشعارات تلقائية

## 🚀 البدء السريع

### تثبيت
```bash
npm install
cd client && npm install && cd ..
```

### تشغيل
```bash
# Terminal 1: Server
npm start

# Terminal 2: Client
cd client && npm run dev
```

الخادم: http://localhost:3001
الواجهة: http://localhost:5173

## 📁 الهيكل

- `/server` - Express backend
- `/client` - React frontend
- `/output` - الفيديوهات والصوتيات

## 🔧 API Endpoints

- `GET /api/stories` - جلب القصص
- `POST /api/fetch-stories` - جلب من Reddit
- `GET /api/videos` - جلب الفيديوهات
- `GET /api/subreddits` - قائمة Subreddits
- `POST /api/subreddits` - إضافة subreddit

## 📝 الترخيص

MIT
