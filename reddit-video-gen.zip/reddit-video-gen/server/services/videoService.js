import ffmpeg from 'fluent-ffmpeg';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs/promises';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const outputDir = path.join(__dirname, '../../output/videos');

// تأكد من وجود مجلد الإخراج
await fs.mkdir(outputDir, { recursive: true });

export async function createVideo(audioPath, backgroundPath, subtitlesPath, options = {}) {
  return new Promise((resolve, reject) => {
    const {
      format = 'vertical', // vertical (9:16) أو horizontal (16:9)
      duration = 300,
      outputName = `video-${Date.now()}.mp4`
    } = options;

    const outputPath = path.join(outputDir, outputName);

    // تحديد الدقة حسب الصيغة
    const resolution = format === 'vertical' ? '1080x1920' : '1920x1080';
    const fps = 30;

    try {
      ffmpeg()
        .input(backgroundPath)
        .loop(duration) // تكرار الفيديو الخلفي
        .input(audioPath)
        .audioCodec('aac')
        .videoCodec('libx264')
        .size(resolution)
        .fps(fps)
        .on('start', (commandLine) => {
          console.log(`🎬 بدء معالجة الفيديو: ${commandLine}`);
        })
        .on('progress', (progress) => {
          const percentage = Math.round((progress.timemark.split(':').reduce((acc, val) => acc * 60 + parseFloat(val), 0) / duration) * 100);
          console.log(`⏳ تقدم المعالجة: ${percentage}%`);
        })
        .on('end', () => {
          console.log(`✅ تم إنشاء الفيديو بنجاح: ${outputPath}`);
          resolve(outputPath);
        })
        .on('error', (error) => {
          console.error(`❌ خطأ في معالجة الفيديو:`, error.message);
          reject(error);
        })
        .save(outputPath);
    } catch (error) {
      reject(error);
    }
  });
}

export async function addSubtitles(videoPath, subtitlesPath, outputPath) {
  return new Promise((resolve, reject) => {
    try {
      ffmpeg(videoPath)
        .input(subtitlesPath)
        .videoFilter(`subtitles=${subtitlesPath}:force_style='FontName=Arial,FontSize=24,PrimaryColour=&H00FFFFFF'`)
        .on('end', () => {
          console.log(`✅ تم إضافة الترجمة بنجاح`);
          resolve(outputPath);
        })
        .on('error', (error) => {
          console.error(`❌ خطأ في إضافة الترجمة:`, error.message);
          reject(error);
        })
        .save(outputPath);
    } catch (error) {
      reject(error);
    }
  });
}

export async function mixAudio(videoPath, backgroundAudioPath, narratorAudioPath, outputPath) {
  return new Promise((resolve, reject) => {
    try {
      ffmpeg()
        .input(videoPath)
        .input(backgroundAudioPath)
        .input(narratorAudioPath)
        .complexFilter([
          '[1:a]volume=0.3[bg]',
          '[2:a]volume=1.0[narrator]',
          '[bg][narrator]amix=inputs=2:duration=first[a]'
        ])
        .map('[a]')
        .audioCodec('aac')
        .on('end', () => {
          console.log(`✅ تم خلط الصوت بنجاح`);
          resolve(outputPath);
        })
        .on('error', (error) => {
          console.error(`❌ خطأ في خلط الصوت:`, error.message);
          reject(error);
        })
        .save(outputPath);
    } catch (error) {
      reject(error);
    }
  });
}

export async function getVideoInfo(videoPath) {
  return new Promise((resolve, reject) => {
    ffmpeg.ffprobe(videoPath, (error, metadata) => {
      if (error) {
        reject(error);
      } else {
        resolve({
          duration: metadata.format.duration,
          bitrate: metadata.format.bit_rate,
          size: metadata.format.size,
          streams: metadata.streams
        });
      }
    });
  });
}
