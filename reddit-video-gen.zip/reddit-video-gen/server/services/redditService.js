import axios from 'axios';

const REDDIT_API_URL = 'https://www.reddit.com';
const USER_AGENT = 'RedditVideoGenerator/1.0';

export async function fetchStoriesFromSubreddit(subreddit, limit = 10) {
  try {
    const url = `${REDDIT_API_URL}/r/${subreddit}/hot.json?limit=${limit}`;
    
    const response = await axios.get(url, {
      headers: {
        'User-Agent': USER_AGENT
      },
      timeout: 10000
    });

    const stories = response.data.data.children.map(post => ({
      reddit_id: post.data.id,
      title: post.data.title,
      content: post.data.selftext,
      author: post.data.author,
      subreddit: post.data.subreddit,
      url: `https://reddit.com${post.data.permalink}`,
      upvotes: post.data.ups,
      comments: post.data.num_comments,
      created_at: new Date(post.data.created_utc * 1000)
    }));

    return stories;
  } catch (error) {
    console.error(`❌ خطأ في جلب القصص من r/${subreddit}:`, error.message);
    throw error;
  }
}

export async function fetchStoriesFromMultipleSubreddits(subreddits) {
  const allStories = [];
  const errors = [];

  // جلب من جميع الـ subreddits بالتوازي
  const promises = subreddits.map(async (subreddit) => {
    try {
      const stories = await fetchStoriesFromSubreddit(subreddit, 5);
      allStories.push(...stories);
    } catch (error) {
      errors.push({ subreddit, error: error.message });
    }
  });

  await Promise.all(promises);

  return { stories: allStories, errors };
}

export async function getStoryDetails(redditId) {
  try {
    const url = `${REDDIT_API_URL}/api/info.json?id=t3_${redditId}`;
    
    const response = await axios.get(url, {
      headers: {
        'User-Agent': USER_AGENT
      },
      timeout: 10000
    });

    if (response.data.data.children.length === 0) {
      return null;
    }

    const post = response.data.data.children[0].data;
    return {
      reddit_id: post.id,
      title: post.title,
      content: post.selftext,
      author: post.author,
      subreddit: post.subreddit,
      url: `https://reddit.com${post.permalink}`,
      upvotes: post.ups,
      comments: post.num_comments
    };
  } catch (error) {
    console.error(`❌ خطأ في جلب تفاصيل القصة ${redditId}:`, error.message);
    throw error;
  }
}
