import axios from 'axios';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs/promises';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const outputDir = path.join(__dirname, '../../output/audio');

// تأكد من وجود مجلد الإخراج
await fs.mkdir(outputDir, { recursive: true });

export async function generateSpeech(text, language = 'ar') {
  try {
    // محاكاة خدمة TTS (في التطبيق الحقيقي ستستخدم Google Cloud TTS أو خدمة أخرى)
    const audioPath = path.join(outputDir, `speech-${Date.now()}.mp3`);
    
    // إنشاء ملف صوتي وهمي للاختبار
    await fs.writeFile(audioPath, Buffer.from('fake audio data'));
    
    console.log(`✅ تم إنشاء الصوت: ${audioPath}`);
    return {
      audioPath,
      duration: calculateDuration(text),
      language
    };
  } catch (error) {
    console.error(`❌ خطأ في إنشاء الصوت:`, error.message);
    throw error;
  }
}

export async function generateSubtitles(text, duration, language = 'ar') {
  try {
    const subtitles = splitTextToSubtitles(text, duration);
    const srtContent = generateSRT(subtitles);
    
    const subtitlesPath = path.join(outputDir, `subtitles-${Date.now()}.srt`);
    await fs.writeFile(subtitlesPath, srtContent, 'utf-8');
    
    console.log(`✅ تم إنشاء الترجمة: ${subtitlesPath}`);
    return subtitlesPath;
  } catch (error) {
    console.error(`❌ خطأ في إنشاء الترجمة:`, error.message);
    throw error;
  }
}

function calculateDuration(text) {
  // حساب تقريبي للمدة بناءً على عدد الأحرف
  // متوسط 150 كلمة في الدقيقة = 900 حرف في الدقيقة
  const words = text.trim().split(/\s+/).length;
  return Math.ceil((words / 150) * 60); // بالثواني
}

function splitTextToSubtitles(text, duration) {
  const words = text.split(/\s+/);
  const wordsPerSubtitle = Math.ceil(words.length / (duration / 5)); // كل 5 ثواني
  
  const subtitles = [];
  let currentTime = 0;
  
  for (let i = 0; i < words.length; i += wordsPerSubtitle) {
    const subtitleWords = words.slice(i, i + wordsPerSubtitle);
    const subtitleText = subtitleWords.join(' ');
    const subtitleDuration = 5; // 5 ثواني لكل ترجمة
    
    subtitles.push({
      index: Math.floor(i / wordsPerSubtitle) + 1,
      startTime: currentTime,
      endTime: currentTime + subtitleDuration,
      text: subtitleText
    });
    
    currentTime += subtitleDuration;
  }
  
  return subtitles;
}

function generateSRT(subtitles) {
  return subtitles.map(sub => {
    const formatTime = (seconds) => {
      const hours = Math.floor(seconds / 3600);
      const minutes = Math.floor((seconds % 3600) / 60);
      const secs = Math.floor(seconds % 60);
      const ms = Math.floor((seconds % 1) * 1000);
      return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')},${String(ms).padStart(3, '0')}`;
    };
    
    return `${sub.index}\n${formatTime(sub.startTime)} --> ${formatTime(sub.endTime)}\n${sub.text}\n`;
  }).join('\n');
}

export async function synthesizeSpeech(text, options = {}) {
  const { language = 'ar', speed = 1.0 } = options;
  
  try {
    const result = await generateSpeech(text, language);
    const subtitles = await generateSubtitles(text, result.duration, language);
    
    return {
      audioPath: result.audioPath,
      subtitlesPath: subtitles,
      duration: result.duration,
      language
    };
  } catch (error) {
    console.error(`❌ خطأ في تحويل النص إلى صوت:`, error.message);
    throw error;
  }
}
