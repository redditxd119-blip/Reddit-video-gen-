import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { initDatabase, getDatabase, closeDatabase } from './database.js';
import { fetchStoriesFromMultipleSubreddits } from './services/redditService.js';
import cron from 'node-cron';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../client/dist')));

// تهيئة قاعدة البيانات عند بدء التطبيق
let db;

async function initializeApp() {
  try {
    db = await initDatabase();
    console.log('✅ تم تهيئة التطبيق بنجاح');
  } catch (error) {
    console.error('❌ خطأ في تهيئة التطبيق:', error);
    process.exit(1);
  }
}

// API Routes

// جلب القصص
app.get('/api/stories', async (req, res) => {
  try {
    const stories = await db.all('SELECT * FROM stories ORDER BY created_at DESC LIMIT 20');
    res.json({ success: true, data: stories });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// جلب قصة واحدة
app.get('/api/stories/:id', async (req, res) => {
  try {
    const story = await db.get('SELECT * FROM stories WHERE id = ?', [req.params.id]);
    if (!story) {
      return res.status(404).json({ success: false, error: 'القصة غير موجودة' });
    }
    res.json({ success: true, data: story });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// جلب الفيديوهات
app.get('/api/videos', async (req, res) => {
  try {
    const videos = await db.all(`
      SELECT v.*, s.title as story_title 
      FROM videos v 
      LEFT JOIN stories s ON v.story_id = s.id 
      ORDER BY v.created_at DESC LIMIT 20
    `);
    res.json({ success: true, data: videos });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// جلب الـ subreddits
app.get('/api/subreddits', async (req, res) => {
  try {
    const subreddits = await db.all('SELECT * FROM subreddits WHERE enabled = 1');
    res.json({ success: true, data: subreddits });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// إضافة subreddit جديد
app.post('/api/subreddits', async (req, res) => {
  try {
    const { name } = req.body;
    if (!name) {
      return res.status(400).json({ success: false, error: 'اسم الـ subreddit مطلوب' });
    }
    
    await db.run('INSERT INTO subreddits (name) VALUES (?)', [name]);
    res.json({ success: true, message: 'تم إضافة الـ subreddit بنجاح' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// جلب القصص من Reddit
app.post('/api/fetch-stories', async (req, res) => {
  try {
    const subreddits = await db.all('SELECT name FROM subreddits WHERE enabled = 1');
    const subredditNames = subreddits.map(s => s.name);
    
    const { stories, errors } = await fetchStoriesFromMultipleSubreddits(subredditNames);
    
    // حفظ القصص في قاعدة البيانات
    let savedCount = 0;
    for (const story of stories) {
      try {
        await db.run(`
          INSERT OR IGNORE INTO stories (reddit_id, title, content, author, subreddit, url, upvotes, comments)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          story.reddit_id,
          story.title,
          story.content,
          story.author,
          story.subreddit,
          story.url,
          story.upvotes,
          story.comments
        ]);
        savedCount++;
      } catch (error) {
        console.error('خطأ في حفظ القصة:', error.message);
      }
    }
    
    res.json({
      success: true,
      message: `تم جلب وحفظ ${savedCount} قصة`,
      saved: savedCount,
      total: stories.length,
      errors
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// الإحصائيات
app.get('/api/stats', async (req, res) => {
  try {
    const totalStories = await db.get('SELECT COUNT(*) as count FROM stories');
    const totalVideos = await db.get('SELECT COUNT(*) as count FROM videos');
    const completedVideos = await db.get("SELECT COUNT(*) as count FROM videos WHERE status = 'completed'");
    const processingVideos = await db.get("SELECT COUNT(*) as count FROM videos WHERE status = 'processing'");
    
    res.json({
      success: true,
      data: {
        totalStories: totalStories.count,
        totalVideos: totalVideos.count,
        completedVideos: completedVideos.count,
        processingVideos: processingVideos.count
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// جدولة جلب القصص تلقائياً كل 24 ساعة
cron.schedule('0 0 * * *', async () => {
  console.log('🔄 جاري جلب القصص المجدولة...');
  try {
    const subreddits = await db.all('SELECT name FROM subreddits WHERE enabled = 1');
    const subredditNames = subreddits.map(s => s.name);
    
    const { stories } = await fetchStoriesFromMultipleSubreddits(subredditNames);
    
    for (const story of stories) {
      try {
        await db.run(`
          INSERT OR IGNORE INTO stories (reddit_id, title, content, author, subreddit, url, upvotes, comments)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          story.reddit_id,
          story.title,
          story.content,
          story.author,
          story.subreddit,
          story.url,
          story.upvotes,
          story.comments
        ]);
      } catch (error) {
        console.error('خطأ في حفظ القصة:', error.message);
      }
    }
    
    console.log(`✅ تم جلب ${stories.length} قصة جديدة`);
  } catch (error) {
    console.error('❌ خطأ في الجدولة:', error.message);
  }
});

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/dist/index.html'));
});

// بدء الخادم
async function startServer() {
  await initializeApp();
  
  app.listen(PORT, () => {
    console.log(`🚀 الخادم يعمل على المنفذ ${PORT}`);
    console.log(`📍 الرابط: http://localhost:${PORT}`);
  });
}

// معالجة الإيقاف الآمن
process.on('SIGINT', async () => {
  console.log('\n🛑 جاري إيقاف الخادم...');
  await closeDatabase();
  process.exit(0);
});

startServer().catch(error => {
  console.error('❌ خطأ في بدء الخادم:', error);
  process.exit(1);
});
